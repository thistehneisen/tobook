<?php
echo $tpl['calendar']->getMonthHTML($_GET['month'], $_GET['year']);
?>