<?php

class NewsletterMailerAPI {

    var $url;
    var $key;

    public function __construct($url, $key) {
        $this->url = $url;
        $this->key = $key;
    }

    public function addSubscriber($data) {
        $ch = curl_init();
        $request_api = $this->url . "api/subscribers/add/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("data" => json_encode($data)));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);

        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }

    public function formAddSubscriber($id, $data) {
        $ch = curl_init();
        $request_api = $this->url . "api/forms/add/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("FormId" => $id, "data" => json_encode($data)));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);

        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }

    public function checkSubscriber($mail) {
        $ch = curl_init();
        $request_api = $this->url . "api/subscribers/exist/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("e-mail" => $mail));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);

        if ($info['http_code'] == 200) {
            if ($output > 0) {
                return true;
            } else if ($output[0] == "0") {
                return false;
            }
        }

        return array("status" => "Error", "msg" => $output);
    }

    public function getCategories() {
        $ch = curl_init();
        $request_api = $this->url . "api/categories/get/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);
        $auth = '';
        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }

    public function getForms() {
        $ch = curl_init();
        $request_api = $this->url . "api/forms/get/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);
        $auth = '';
        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }

    public function getForm($id) {
        $ch = curl_init();
        $request_api = $this->url . "api/forms/info/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("id" => $id));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);
        $auth = '';
        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }
    
    public function addToCategory($emails,$category_ids) {
        $ch = curl_init();
        $request_api = $this->url . "api/categories/add/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        if(!is_array($emails)){
            $emails=array($emails);
        }
        if(!is_array($category_ids)){
            $category_ids=array($category_ids);
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("emails" => json_encode($emails),"category_ids" => json_encode($category_ids)));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);
        $auth = '';
        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }
    
    public function removeFromCategory($emails,$category_ids) {
        $ch = curl_init();
        $request_api = $this->url . "api/categories/remove/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        if(!is_array($emails)){
            $emails=array($emails);
        }
        if(!is_array($category_ids)){
            $category_ids=array($category_ids);
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("emails" => json_encode($emails),"category_ids" => json_encode($category_ids)));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);
        $auth = '';
        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }

    public function getFormMessage($id) {
        $ch = curl_init();
        $request_api = $this->url . "api/forms/message/" . $this->key;
        curl_setopt($ch, CURLOPT_URL, $request_api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("id" => $id));
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        $ret = @json_decode($output, true);
        $auth = '';
        if ($info['http_code'] == 200 && !empty($ret)) {
            return $ret;
        }

        return array("status" => "Error", "msg" => $output);
    }

}

?>
