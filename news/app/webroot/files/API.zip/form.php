<?php

if(isset($_POST["data"]["Form"])){
	require_once 'NewsletterMailerAPI.php';
	$nlapi = new NewsletterMailerAPI("URL", "APIKEY");
	$data=$_POST["data"]["Form"];
	//categories ids
	$data["Category"] = array(5);
	if (!$nlapi->checkSubscriber($data["e-mail"])) {
		$return = $nlapi->addSubscriber($data);
		if ($return["status"] == "ok") {
			echo "Subscriber added";
		} else {
			echo "Add Subscriber Failed:" . $return["msg"];
		}
	}else{
		echo "Subscriber exists";
	} 
}
?>
<form id="FormViewForm" method="post" action="" accept-charset="utf-8">
<div class="input text"><label for="FormFirstName">First Name</label><input name="data[Form][first_name]" type="text" id="FormFirstName" /></div>
<div class="input text"><label for="FormLastName">Last Name</label><input name="data[Form][last_name]" type="text" id="FormLastName" /></div>
<div class="input text"><label for="FormE-mail">E-Mail</label><input name="data[Form][e-mail]" type="text" id="FormE-mail" /></div>
 <div class="submit"><input type="submit" value="Subscribe new!" /></div></form>
