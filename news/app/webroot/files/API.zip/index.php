<pre><?php

require_once 'NewsletterMailerAPI.php';
$nlapi = new NewsletterMailerAPI("http://192.168.1.33/newsletter/", "4b1580b4370de7d682d7f8495398488e");


//Get existing Categories
print_r($nlapi->addToCategory("ail@test.com",1));
print_r($nlapi->addToCategory(array("ail@test.com","ail@test.com"),1));
print_r($nlapi->addToCategory(array("ail@test.com","ynhwebdev@gmail.com"),array(3,4,5,6,7)));
print_r($nlapi->removeFromCategory(array("ail@test.com","ynhwebdev@gmail.com"),array(3,4,5,6,7))); 
?></pre>
