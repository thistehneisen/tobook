<?php

class Home extends AppModel {

    var $useTable = false;

    
}

?>