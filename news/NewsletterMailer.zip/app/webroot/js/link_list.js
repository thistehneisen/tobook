var tinyMCELinkList = new Array(
	// Name, URL
	["Unsubscribe", "{$unsubscribe}"],
        ["Send to Friend", "{$sendtofriend}"],
	["View in Browser", "{$browerslink}"],
        ["Update Subscriber", "{$update_subscriber}"],
        	["Confirm Subscription", "{$confirm}"]
);
