var tinyMCELinkList = new Array(
	// Name, URL
 
        	["Confirm Subscription", "{$confirm}"]
);
