<?php
class Install extends InstallAppModel {

    var $name = 'Install';
    var $useTable = false;

}
?>