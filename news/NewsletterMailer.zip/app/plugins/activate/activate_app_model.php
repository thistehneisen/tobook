<?php
class ActivateAppModel extends AppModel {

}
?>