<?php
class ActivateAppController extends AppController {

    function beforeFilter() {
        
    }

}
?>