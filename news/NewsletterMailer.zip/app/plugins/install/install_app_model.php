<?php
class InstallAppModel extends AppModel {

}
?>