<?php
class InstallAppController extends AppController {

    function beforeFilter() {
        
    }

}
?>