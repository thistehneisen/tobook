<?php
class MailsCategoriesController extends AppController {

	var $name = 'MailsCategories';

	
}
?>