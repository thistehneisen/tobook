<?php
			/**
			* @package BJ ImageSlider
			* @copyright (C) 2008-2011 byjoomla.com
			* @author byjoola.com
			* @version 2011-March-13rd v.1.6.0
			* 
			* --------------------------------------------------------------------------------
			* All rights reserved. BJ ImageSlider for Joomla!
			*
			* --------------------------------------------------------------------------------
			**/

			defined( '_JEXEC' ) or die( 'Restricted access' );
			if(!defined('DS'))
			define('DS', DIRECTORY_SEPARATOR);
			$bj_ss_path = '/images/stories/_bj_imageslider';
			$bj_ss_absolute_path = DS . 'images' . DS . 'stories' . DS . '_bj_imageslider';
			$bj_ss_image_height = '300';
$bj_ss_image_width = '960';
$bj_ss_thumb_height = '35';
$bj_ss_thumb_width = '52';

?>