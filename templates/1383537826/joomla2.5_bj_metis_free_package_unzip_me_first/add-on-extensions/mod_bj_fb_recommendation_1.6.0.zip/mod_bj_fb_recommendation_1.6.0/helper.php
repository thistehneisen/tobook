<?php
/**
* @version		2010-11-06 hadoanngoc
* @package		BJ_FB_Recommend
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class modBJFBRecommendHelper
{
	
}
