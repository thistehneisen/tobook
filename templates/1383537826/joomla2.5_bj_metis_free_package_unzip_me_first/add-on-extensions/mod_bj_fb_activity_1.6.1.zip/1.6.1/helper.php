<?php
/**
* @version		2010-11-06 hadoanngoc
* @package		BJ_FB_Activity
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class modBJFBActivityHelper
{
	
}
