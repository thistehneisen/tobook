<?php
/**
* @version		$Id: helper.php 11299 2008-11-22 01:40:44Z ian $
* @package		BJ_NewsTabber
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class modBJPhotoGalleryHelper
{
	
}
